# from django.contrib import admin
# from application1.models import Login


# class LoginAttempt_Admin(admin.ModelAdmin):
#     list_display=('username','password')
# admin.site.register(Login,LoginAttempt_Admin)

# # Register your models here.



from django.contrib import admin
from .models import Login

class LoginAdmin(admin.ModelAdmin):
    list_display = ('username', 'timestamp')
    search_fields = ('username',)

admin.site.register(Login, LoginAdmin)
