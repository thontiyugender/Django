#from django.shortcuts import render
# from application1.models import Login
# from django.http import HttpResponse
# def Testcase1(request):
#     username = Login.input("Enter the Username: ")
#     password = Login.input("Enter the Password: ")
#     if(username==username and password==password):
#         print(f"Welcome {username}, YOU'RE IN...")
#     else:
#         print("Who are you?.....")
#     return HttpResponse(Login)
# # return render(request)



from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.hashers import check_password
from .models import Login

def Testcase1(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        try:
            # user = Login.objects.get(username=username)
            # if check_password(password, user.password):
            #     return HttpResponse(f"Welcome {username}, YOU'RE IN...")
            # else:
            #     return HttpResponse("Invalid password. Who are you?")
            
            if(username==username and password==password):
                return HttpResponse(f"Welcome BOSS... what's Going On...")
            else:
                return HttpResponse("Invalid password....Who are you?")


        except Login.DoesNotExist:
            return HttpResponse("Username not found. Who are you?")
    return render(request, "login_form.html")




# from django.contrib.auth import authenticate

# username = input("Enter the Username: ")
# password = input("Enter the Password: ")

# user = authenticate(username=username, password=password)
# if user is not None:
#     print(f"Welcome {user.username}, YOU'RE IN...")
# else:
#     print("Who are you?....")
