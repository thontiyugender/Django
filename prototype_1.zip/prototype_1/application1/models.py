from django.db import models
from django.contrib.auth.hashers import make_password

class Login(models.Model):
    username = models.CharField(max_length=150, unique=True)
    password = models.CharField(max_length=128)  # Storing hashed passwords
    timestamp = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        # Automatically hash the password before saving the user
        if not self.pk:  # Hash password only for new users
            self.password = make_password(self.password)
        super(Login, self).save(*args, **kwargs)
