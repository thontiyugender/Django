from django.apps import AppConfig


class Application4Config(AppConfig):
    name = 'application4'
