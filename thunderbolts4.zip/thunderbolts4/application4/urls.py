from django.conf.urls import url
from application4 import views


urlpatterns = [
    url(r'^v1/',views.test_case1),
    url(r'^v2/',views.test_case2),
    url(r'^v3/',views.test_case3),
    url(r'^v4/',views.test_case4),
    url(r'^v5/',views.test_case5),

]
