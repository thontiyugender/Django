from django.shortcuts import render
from django.http import HttpResponse
def test_case1(request):
    return HttpResponse("<h1><tt>this is service_oneM</tt></h1>")
def test_case2(request):
     return HttpResponse("<h1><tt>this is service_two</tt></h1>")
def test_case3(request):
    return HttpResponse("<h1><tt>this is service_three</tt></h1>")
def test_case4(request):
    return HttpResponse("<h1><tt>this is service_four</tt></h1>")
def test_case5(request):
    return HttpResponse("<h1><tt>this is service_five</tt></h1>")
    



# Create your views here.
