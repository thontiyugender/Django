from django.shortcuts import render
def Testcase1(request):
    Response=render(request,'application1/S1.html')
    Response.set_cookie("name","IHUB_IT_SERVICES")
    return Response
def Testcase2(request):
    name=request.COOKIES.get("name","cookies are not found")
    return render(request,"application1/S2.html",{'name':name})
def Testcase3(request):
    Response=render(request,"application1/S3.html")
    Response.delete_cookie("name")
    return Response


