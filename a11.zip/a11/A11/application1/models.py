from django.db import models
class Products(models.Model):
    Pid=models.IntegerField()
    Pname=models.CharField(max_length=30)
    Price=models.FloatField()
    Company=models.CharField(max_length=30)
  


