from django.shortcuts import render
from  django.http import HttpResponse
def prototype_1(request):
    return HttpResponse("<hr><center><h1><tt>WELCOME TO virtual_reatily from MAYURA_TECHNOLOGIES....</tt></h1></center><hr>")
def prototype_2(request):
    return HttpResponse("<hr><center><h1><tt>WELCOME TO ai from MAYURA_TECHNOLOGIES....</tt></h1></center><hr>")
def prototype_3(request):
    return HttpResponse("<hr><center><h1><tt>WELCOME TO search_engine from MAYURA_TECHNOLOGIES....</tt></h1></center><hr>")









