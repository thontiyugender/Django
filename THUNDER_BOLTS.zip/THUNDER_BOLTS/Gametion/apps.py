from django.apps import AppConfig


class GametionConfig(AppConfig):
    name = 'Gametion'
