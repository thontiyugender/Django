from django.db import models
class customers(models.Model):
    First_name=models.CharField(max_length=25)
    Last_name=models.CharField(max_length=25)
    username=models.CharField(max_length=25)
    p1=models.CharField(max_length=25)
    p2=models.CharField(max_length=25)
    Mobile_Number=models.CharField(max_length=25)
    Email=models.CharField(max_length=25)

    def __str__(self):
        return self.First_name+" "+self.Last_name+" "+self.username+" "+self.p1+" "+self.p2+" "+self.Mobile_Number+" "+self.Email

