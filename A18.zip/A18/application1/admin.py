from django.contrib import admin
from application1.models import customers
class customers_admin(admin.ModelAdmin):
    list_display=['First_name',"Last_name","username","p1","p2","Mobile_Number","Email"]
admin.site.register(customers,customers_admin)

