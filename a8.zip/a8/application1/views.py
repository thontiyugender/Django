from django.shortcuts import render
# from application1 import views
def test_case1(request):
    return render(request,"application1/S5.html")

# Create your views here.
