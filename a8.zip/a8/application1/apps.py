from django.apps import AppConfig


class Application1Config(AppConfig):
    name = 'application1'
