function test_case1()
{
    window.alert("YOU ARE IN WRONG DESTINATION")
}