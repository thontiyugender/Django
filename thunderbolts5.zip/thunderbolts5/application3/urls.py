from django.conf.urls import url
from application3 import views


urlpatterns = [
   
    url(r'^v3/',views.test_case3),
 
]
