from django.apps import AppConfig


class Application3Config(AppConfig):
    name = 'application3'
