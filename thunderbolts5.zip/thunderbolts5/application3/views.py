from django.shortcuts import render
from django.http import HttpResponse
def test_case3(request):
    return HttpResponse("<h1><tt><mark>this is third</mark></tt></h1>")

# Create your views here.
