from django.apps import AppConfig


class Application2Config(AppConfig):
    name = 'application2'
