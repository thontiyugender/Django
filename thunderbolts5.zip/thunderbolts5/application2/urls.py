from django.conf.urls import url
from application2 import views


urlpatterns = [
    url(r'^v2/',views.test_case2),


]
