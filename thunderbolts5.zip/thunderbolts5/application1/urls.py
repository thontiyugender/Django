from django.conf.urls import url
from application1 import views

urlpatterns = [
     url(r'^v1/',views.test_case1),
]
