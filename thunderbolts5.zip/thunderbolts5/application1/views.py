from django.shortcuts import render
from django.http import HttpResponse
def test_case1(request):
    return HttpResponse("<h1><tt><mark>this is first</mark></tt></h1>")

# Create your views here.
