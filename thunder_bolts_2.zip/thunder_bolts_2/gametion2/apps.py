from django.apps import AppConfig


class Gametion2Config(AppConfig):
    name = 'gametion2'
