from django.shortcuts import render
from django.http import HttpResponse
from django.views import View
class prototype_1(View):
    def get(self,request):
        return HttpResponse("<h1><tt>This is first prototype.....</tt></h1>")
class prototype_2(View):
    def get(self,request):
        return HttpResponse("<h1><tt>This is second prototype.....</tt></h1>")
class prototype_3(View):
    def get(self,request):
        return HttpResponse("<h1><tt>This is third prototype.....</tt></h1>")

