from django.shortcuts import render
def test_case1(request):
    return render(request,"application1/S2.html")

# Create your views here.
