from django.apps import AppConfig


class Gametion3Config(AppConfig):
    name = 'gametion3'
