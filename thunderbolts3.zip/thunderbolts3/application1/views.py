from django.shortcuts import render
from django.http import HttpResponse
def test_case1(request):
    return HttpResponse("<h1> this is service_one from application_1</h1>")

# Create your views here.
