from django.shortcuts import render

from django.http import HttpResponse
def test_case3(request):
    return HttpResponse("<h1> this is service_three from application_3</h1>")


# Create your views here.
