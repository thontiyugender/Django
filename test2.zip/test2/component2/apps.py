from django.apps import AppConfig


class Component2Config(AppConfig):
    name = 'component2'
