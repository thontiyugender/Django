from django.shortcuts import render
from django.http import HttpResponse
from django.views import View
class oppo(View):
    def get(self,request):
        return HttpResponse('<h1><tt>This is <mark>second</mark> testcase....</tt></h1>')


