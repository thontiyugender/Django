from django.apps import AppConfig


class Component1Config(AppConfig):
    name = 'component1'
