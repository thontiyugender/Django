from django.shortcuts import render
from django.http import HttpResponse
from django.views import View
def vision(request):
    return HttpResponse('<h1><tt>THIS IS <mark>FIRST</mark> TESTCASE....</tt></H1>')
