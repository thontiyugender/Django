from django import forms
class products(forms.Form):
    pid=forms.IntegerField(label="pid")
    pname=forms.CharField(max_length=25,label="pname")
    price=forms.FloatField(label="price")
    company=forms.CharField(max_length=25,label="company")
    m_date=forms.DateField(label="m_date")
    exp_date=forms.DateField(label="exp_date")