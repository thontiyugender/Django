from django.shortcuts import render
from application1.forms import products
def test_case1(request):
    form=products()
    return render(request,"application1/s1.html",{'form':form})
# Create your views here.
