function test_case1()
{
    window.alert("YOU IMBISCLE BRAT...go and check the code...")
}