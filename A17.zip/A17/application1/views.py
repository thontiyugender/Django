from django.shortcuts import render
def Test_case1(request):
    request.session['name']="Ramanasoft_IT_services"
    return render(request,"application1/s1.html")
def Test_case2(request):
    name=request.session.get('name',default="session is not found....")
    return render (request,"application1/s2.html",{'name':name})
def Test_case3(request):
    if 'name' in request.session:
        del request.session['name']
    return render(request,"application1/s3.html")

