from django.shortcuts import render
def testcase1(request):
    return render(request,"app1/s1.html")

# Create your views here.
