from django.contrib import admin
from application1.models import students
class student_admin(admin.ModelAdmin):
    list_display=['sid','sname','subject','marks']
admin.site.register(students,student_admin)

# Register your models here.