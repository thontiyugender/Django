from django.shortcuts import render
from application1.models import students
from django.http import HttpResponse
# def test_case1(request):
#     data=students.objects.get(sid=100)
#     return HttpResponse(data)


def test_case1(request):
    try:
        data=students.objects.get(sid=12)
    except:
        return HttpResponse("<h1>Exception name is:Data/information is not found</h1>")
    return HttpResponse(data)
# Create your views here.
